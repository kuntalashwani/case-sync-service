package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);

		String apiUrl = "https://api.agify.io/?name=jitendra";
		String result = callApi(apiUrl);
		System.out.println("API Response: " + result);
	}

	private static String callApi(String apiUrl) {
		RestTemplate restTemplate = new RestTemplate();
		return restTemplate.getForObject(apiUrl, String.class);
	}
}
